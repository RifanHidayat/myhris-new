import 'dart:convert';
import 'package:get/get.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

class HistoryController extends GetxController {
  var status = 0.obs;


  @override
  void onReady() {
    super.onReady();
    
  }

  @override
  void onClose() {
    
    super.onClose();
  }

  @override
  void onInit() async {
  
    super.onInit();
  }


}
